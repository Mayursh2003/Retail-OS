from datetime import datetime
from uuid import UUID

from sqlalchemy import DateTime, Float, Integer, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID as PGUUID
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base


class FrameResultRecord(Base):
    """Persisted canonical Vision FrameResult."""

    __tablename__ = "frame_results"

    __table_args__ = (
        UniqueConstraint(
            "frame_id",
            name="uq_frame_results_frame_id",
        ),
    )

    id: Mapped[int] = mapped_column(
        Integer,
        primary_key=True,
        autoincrement=True,
    )
    frame_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        nullable=False,
        index=True,
    )
    camera_id: Mapped[UUID] = mapped_column(
        PGUUID(as_uuid=True),
        nullable=False,
        index=True,
    )
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False,
        index=True,
    )
    frame_number: Mapped[int] = mapped_column(
        Integer,
        nullable=False,
    )
    processing_time_ms: Mapped[float] = mapped_column(
        Float,
        nullable=False,
    )
    persons: Mapped[list] = mapped_column(
        JSONB,
        nullable=False,
    )
