from datetime import datetime, timezone
from uuid import uuid4

from app.database.models import FrameResultRecord


def test_frame_result_record_contains_persistence_fields() -> None:
    frame_id = uuid4()
    camera_id = uuid4()
    timestamp = datetime.now(timezone.utc)

    record = FrameResultRecord(
        frame_id=frame_id,
        camera_id=camera_id,
        timestamp=timestamp,
        frame_number=42,
        processing_time_ms=18.4,
        persons=[],
    )

    assert record.frame_id == frame_id
    assert record.camera_id == camera_id
    assert record.timestamp == timestamp
    assert record.frame_number == 42
    assert record.processing_time_ms == 18.4
    assert record.persons == []
