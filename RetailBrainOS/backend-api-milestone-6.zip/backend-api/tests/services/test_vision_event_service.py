from datetime import datetime, timezone
from uuid import uuid4

from shared.vision import FrameResult

from app.services.vision_event_service import VisionEventService


class FakeDB:
    def __init__(self) -> None:
        self.added = []
        self.committed = False

    def add(self, record) -> None:
        self.added.append(record)

    def commit(self) -> None:
        self.committed = True


class FakeQueue:
    def __init__(self) -> None:
        self.submitted = []

    def submit(self, frame_result) -> None:
        self.submitted.append(frame_result)


def make_frame_result() -> FrameResult:
    return FrameResult(
        frame_id=uuid4(),
        camera_id=uuid4(),
        timestamp=datetime.now(timezone.utc),
        frame_number=10,
        processing_time_ms=12.5,
        persons=[],
    )


def test_service_persists_and_submits_frame_result() -> None:
    frame = make_frame_result()
    db = FakeDB()
    queue = FakeQueue()

    result = VisionEventService(db=db, queue=queue).ingest_frame_result(frame)

    record = db.added[0]

    assert result is frame
    assert db.committed is True
    assert record.frame_id == frame.frame_id
    assert record.camera_id == frame.camera_id
    assert record.timestamp == frame.timestamp
    assert record.frame_number == frame.frame_number
    assert record.processing_time_ms == frame.processing_time_ms
    assert record.persons == []
    assert queue.submitted == [frame]
