from abc import ABC, abstractmethod

from shared.vision import FrameResult


class FrameResultQueue(ABC):
    """Abstraction for asynchronous FrameResult processing."""

    @abstractmethod
    def submit(self, frame_result: FrameResult) -> None:
        """Submit a FrameResult for asynchronous processing."""
        raise NotImplementedError
