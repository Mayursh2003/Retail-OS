from datetime import datetime, timezone
from uuid import uuid4

from fastapi.testclient import TestClient

from app.api.v1.vision import get_frame_result_queue
from app.core.application import create_application
from app.database.database import get_db


class FakeDB:
    def __init__(self) -> None:
        self.records = []
        self.committed = False

    def add(self, record) -> None:
        self.records.append(record)

    def commit(self) -> None:
        self.committed = True


class FakeQueue:
    def __init__(self) -> None:
        self.submitted = []

    def submit(self, frame_result) -> None:
        self.submitted.append(frame_result)


def make_payload() -> dict:
    return {
        "frame_id": str(uuid4()),
        "camera_id": str(uuid4()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "frame_number": 1,
        "processing_time_ms": 15.5,
        "persons": [],
    }


def test_valid_frame_result_is_accepted() -> None:
    app = create_application()
    db = FakeDB()
    queue = FakeQueue()

    def override_db():
        yield db

    def override_queue():
        return queue

    app.dependency_overrides[get_db] = override_db
    app.dependency_overrides[get_frame_result_queue] = override_queue

    response = TestClient(app).post(
        "/api/v1/vision/frames",
        json=make_payload(),
    )

    assert response.status_code == 202
    assert response.json()["status"] == "accepted"
    assert len(db.records) == 1
    assert len(queue.submitted) == 1


def test_invalid_frame_result_is_rejected() -> None:
    app = create_application()

    def override_queue():
        return FakeQueue()

    app.dependency_overrides[get_frame_result_queue] = override_queue

    response = TestClient(app).post(
        "/api/v1/vision/frames",
        json={
            "frame_id": "not-a-uuid",
            "camera_id": "not-a-uuid",
        },
    )

    assert response.status_code == 422
