"""create frame_results table

Revision ID: 7aa1140f8d9a
Revises: None
Create Date: 2026-08-09
"""

from collections.abc import Sequence

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision: str = "7aa1140f8d9a"
down_revision: str | Sequence[str] | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "frame_results",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("frame_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("camera_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("timestamp", sa.DateTime(timezone=True), nullable=False),
        sa.Column("frame_number", sa.Integer(), nullable=False),
        sa.Column("processing_time_ms", sa.Float(), nullable=False),
        sa.Column("persons", postgresql.JSONB(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("frame_id", name="uq_frame_results_frame_id"),
    )
    op.create_index("ix_frame_results_frame_id", "frame_results", ["frame_id"])
    op.create_index("ix_frame_results_camera_id", "frame_results", ["camera_id"])
    op.create_index("ix_frame_results_timestamp", "frame_results", ["timestamp"])


def downgrade() -> None:
    op.drop_index("ix_frame_results_timestamp", table_name="frame_results")
    op.drop_index("ix_frame_results_camera_id", table_name="frame_results")
    op.drop_index("ix_frame_results_frame_id", table_name="frame_results")
    op.drop_table("frame_results")
