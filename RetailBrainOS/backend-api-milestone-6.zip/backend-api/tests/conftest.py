from app.core.config import settings

# Tests use an in-memory SQLAlchemy engine only to import the application
# without requiring a PostgreSQL server. Production remains PostgreSQL.
settings.DATABASE_URL = "sqlite+pysqlite:///:memory:"
