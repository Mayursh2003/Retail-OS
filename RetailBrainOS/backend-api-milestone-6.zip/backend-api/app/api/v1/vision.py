from fastapi import APIRouter, Depends, status
from pydantic import BaseModel
from sqlalchemy.orm import Session

from shared.vision import FrameResult

from app.database.database import get_db
from app.queue.interface import FrameResultQueue
from app.services.vision_event_service import VisionEventService


router = APIRouter(
    prefix="/vision",
    tags=["Vision"],
)


class FrameResultAcknowledgement(BaseModel):
    status: str
    frame_id: str


def get_frame_result_queue() -> FrameResultQueue:
    """
    Resolve the configured FrameResult queue.

    A concrete production queue is intentionally not provided until
    the queue technology is approved.
    """
    raise NotImplementedError(
        "A production FrameResult queue requires CTO confirmation."
    )


@router.post(
    "/frames",
    response_model=FrameResultAcknowledgement,
    status_code=status.HTTP_202_ACCEPTED,
)
def ingest_frame_result(
    frame_result: FrameResult,
    db: Session = Depends(get_db),
    queue: FrameResultQueue = Depends(get_frame_result_queue),
) -> FrameResultAcknowledgement:
    service = VisionEventService(db=db, queue=queue)
    accepted = service.ingest_frame_result(frame_result)

    return FrameResultAcknowledgement(
        status="accepted",
        frame_id=str(accepted.frame_id),
    )
