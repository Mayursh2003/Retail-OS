from app.database.models.frame_result import FrameResultRecord

__all__ = ["FrameResultRecord"]
