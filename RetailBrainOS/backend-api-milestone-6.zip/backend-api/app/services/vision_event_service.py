from shared.vision import FrameResult
from sqlalchemy.orm import Session

from app.database.models.frame_result import FrameResultRecord
from app.queue.interface import FrameResultQueue


class VisionEventService:
    """Accept and persist canonical FrameResult data, then queue it."""

    def __init__(self, db: Session, queue: FrameResultQueue) -> None:
        self.db = db
        self.queue = queue

    def ingest_frame_result(self, frame_result: FrameResult) -> FrameResult:
        record = FrameResultRecord(
            frame_id=frame_result.frame_id,
            camera_id=frame_result.camera_id,
            timestamp=frame_result.timestamp,
            frame_number=frame_result.frame_number,
            processing_time_ms=frame_result.processing_time_ms,
            persons=frame_result.model_dump(mode="json")["persons"],
        )

        self.db.add(record)
        self.db.commit()

        self.queue.submit(frame_result)

        return frame_result
